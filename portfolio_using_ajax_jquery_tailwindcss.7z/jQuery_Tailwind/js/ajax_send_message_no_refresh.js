$(document).ready(function () {
    $('#messageForm').submit(function (e) {
        e.preventDefault(); // Prevent the form from submitting in the traditional way

        var form = $(this);
        var url = form.attr('action');
        var formData = form.serialize(); // Serialize form data

        // Send an AJAX request
        $.ajax({
            type: 'POST',
            url: url,
            data: formData,
            dataType: 'json', // Specify that you expect JSON as the response
            success: function (data) {
                $('#messageResult').html(data.message); // Display the "message" key from the JSON response
            }
        });
    });
});
