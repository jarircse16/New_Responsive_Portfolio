$(document).ready(function () {
  var expandedSection = null;

  function toggleSection(sectionName) {
    if (expandedSection === sectionName) {
      $(`#detailed-${sectionName}`).hide("slow");
      expandedSection = null;
    } else {
      if (expandedSection) {
        $(`#detailed-${expandedSection}`).hide("slow");
      }
      $(`#detailed-${sectionName}`).show("slow");
      expandedSection = sectionName;
    }
  }

  function updateTextColor(sectionName) {
    var color = expandedSection === sectionName ? "blue" : "red";
    $(`#${sectionName}Paragraph`).css("color", color);
  }

  $("#aboutButton").click(function () {
    toggleSection("about");
    updateTextColor("about");
  });

  $("#projectButton").click(function () {
    toggleSection("project");
    updateTextColor("project");
  });

  $("#contactButton").click(function () {
    toggleSection("contact");
    updateTextColor("contact");
  });

  $("#show-more-about").click(function (e) {
    e.preventDefault();
    toggleSection("about");
    updateTextColor("about");
  });

  $("#show-more-project").click(function (e) {
    e.preventDefault();
    toggleSection("project");
    updateTextColor("project");
  });

  $("#show-more-contact").click(function (e) {
    e.preventDefault();
    toggleSection("contact");
    updateTextColor("contact");
  });

  $("#detailed-about").animate({
    width: '200px',
    height: '200px',
    opacity: 0.5
  }, 1000);

  $("#detailed-project").animate({
    width: '500px',
    height: '200px',
    opacity: 0.5
  }, 1000);

  $("#detailed-contact").animate({
    width: '200px',
    height: '200px',
    opacity: 0.5
  }, 1000);
});
