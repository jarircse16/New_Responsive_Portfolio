<?php

echo '
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="css\tailwind_final.css">
    <!--<link rel="stylesheet" href="css\styles.css">-->
    <title>Your Portfolio</title>
</head>
<header class="text-center bg-blue-500 text-4xl text-black p-4">
    <center><h1>Welcome to my portfolio</h1></center>
</header>
<body class="font-sans bg-gray-300 m-0 p-0">

<div class="container">
  <section id="about" class="flex">
    <div class="about-image">
      <img src="images/your-image-link.jpg.png" alt="Your Image">
    </div>
    <div class="about-info">
      <button id="aboutButton" style="color: red;">About Me</button>
      <p id="aboutParagraph"></p>
      <a href="#" id="show-more-about"></a>
      <div id="detailed-about" style="display: none;">
        <p style="color: blue;">Hello! I am Jarir Ahmed, a web developer passionate about creating amazing web applications.
        I have experience in HTML, CSS, PHP, Laravel, JS, ASP, HTA, VBS, and CGI Technologies.
        I also have interests in software development, and I have worked with C#, Java, etc. languages too.
        You can contact me to build an attractive website for you.</p>
      </div>
    </div>
    <div class="about-info">
      <button id="projectButton" style="color: red;">My Projects</button><br><br>
      <p id="projectParagraph"></p>
      <a href="#" id="show-more-project"></a>
      <div id="detailed-project" style="display: none;">
        <p style="color: blue;">Project 1: PHP_CUT _OFF_ WAF<br><br>
        Designed a robust PHP firewall system to protect against a wide range of web vulnerabilities, including SQL injection (SQLi), local file inclusion (LFI), remote file inclusion (RFI), server-side includes (SSI), cross-site scripting (XSS), cross-site request forgery (CSRF), directory traversal, and clickjacking. This firewall intercepts and neutralizes potential threats in URLs, safeguarding users and redirecting them to the homepage when necessary.</p>
        <br>
        <p style="color: blue;">Project 2: Rate_Limit_DDOS_WAF_IP_BLOCK_24<br><br>
        Developed a PHP firewall to detect incoming HTTP GET and POST requests to filter out DDOS attacks using the request limit of 1000 requests per hour. Then it blocks the IP for 24 hours.</p>

      </div>
    </div>
    <div id="contact-section" class="about-info">
        <button id="contactButton" style="color: red;">Contact Me</button><br><br>
        <p id="buttonParagraph"></p>
        <a href="#" id="show-more-contact"></a>
        <div id="detailed-contact" style="display: none;">
        <form id="messageForm" action="send_message.php" method="post">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required><br><br>
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required><br><br>
            <label for="message">Message:</label>
            <textarea id="message" name="message" rows="4" required></textarea><br><br>
            <button type="submit" value="Submit" id="submit">Submit</button>
        </form>
        <div id="messageResult"></div>
    </div>
  </section>
</div>



  <section id="projects">
    </section>
    <section id="contact">
        <!-- Contact form goes here -->
    </section><br><br><br><br><br><br>
    <footer>
    <center><p>&copy; 2023 Jarir Ahmed. All Rights Reserved.</p></center>
    </footer>

    <script src="js\jquery.js"></script>
    <!-- Snake Scroll Bar -->
    <div id="snake-container">
        <div id="snake-bar"></div>
    </div>

    <!-- JavaScript to handle the snake scroll bar -->
    <script src="js/ajax_send_message_no_refresh.js"></script>
    <script src="js/snake.js"></script>
</body>
</html>
';


 ?>
