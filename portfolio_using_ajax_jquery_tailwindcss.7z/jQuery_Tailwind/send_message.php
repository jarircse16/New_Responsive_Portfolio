<?php
// Define the directory where messages will be stored
$messageDirectory = 'messages';

// Create the messages directory if it doesn't exist
if (!is_dir($messageDirectory)) {
    mkdir($messageDirectory, 0755, true);
}

// Generate a unique filename with date-time stamp
$messageFileName = 'message_' . date('Ymd_His') . '.txt';

// Get form data
$name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['message'];

// Define the full path to the message file
$filePath = $messageDirectory . '/' . $messageFileName;

// Write the form data to the text file
$fileContent = "Name: $name\nEmail: $email\nMessage:\n$message";
file_put_contents($filePath, $fileContent);

// Redirect back to the contact form with a success message
//header('Location: index.php?message_sent_success=True');

// Define the response
$response = ['message' => 'Message sent successfully'];

// Return JSON response
echo json_encode($response);
exit;
?>
